import React from 'react';

// This component is no longer used and has been replaced by ComposeEmailView.
const ComposeEmailModal: React.FC = () => {
    return null;
};

export default ComposeEmailModal;